A. Pierce Matthews
CSCE-350
10/22/17

matthews_adam_program1.cpp is the first part of the assignment. It has been included compiled as matthews_adam_Quicksort. 
The second part of the assignment, which generates the input files, has been included as the source file matthews_adam_program1_part2.cpp. To compile execute the command "g++ -Wall -O -g matthews_adam_program1_part2.cpp" and the run the a.out file that is generated. 
run_sort.sh will execute matthews_adam_Quicksort on all the input files in this folder, and create a txt file containing the execution times.
