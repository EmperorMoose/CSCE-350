#!/bin/sh
#A. Pierce Matthews
#CSCE-350 Program 1
#10/22/17

for f in *; do
	./matthews_adam_Quicksort f out.txt >> matthews_adam_executionTime.txt
done